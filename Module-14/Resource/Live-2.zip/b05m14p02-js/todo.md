TODO List

00. Recap ✅
01. Array Methods ✅
02. JS Objects ✅
--  DOM ✅
  * It doesn't affect source Code
  * Node, DOM
  * Resets on reload
03. Selecting Elements ✅
04. Changing Content ✅
05. Event Listener ✅
06. setTimeout ✅
08. clearTimeout ✅
07. setInterval ✅
09. clearInterval ✅
