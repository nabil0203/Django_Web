# Class 6

**Duration:** 90 minutes

## Topics to Discuss:
- Searching: Linear & Binary Search
- Sorting: Bubble, Merge Sort, Quick Sort
- Recursion & divide-and-conquer
