# Class 5

**Duration:** 90 minutes

## Topics to Discuss:
- BST properties
- Insertion, deletion, and search
- Inorder traversal gives sorted order

## Activities:
- Write BST class with insert and search methods
- Demonstrate inorder traversal

## Homework:
- Solve BST insert/delete/search problems on coding platforms
- Practice 3 traversal-based problems
