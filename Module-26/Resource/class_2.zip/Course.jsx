function Course() {
  return (
    <div>
      Course Component
    </div>
  )
}

export default Course